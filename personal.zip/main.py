import cv2
import numpy as np

thresholdValue = 0.5
nmsThresholdValue = 0.2
# net = cv2.

# Opencv DNN
weightsPath = r"D:\Car Detection POC\CarDetectionVenv\dnn_model/yolov4-tiny.weights"
configPath = r"D:\Car Detection POC\CarDetectionVenv\dnn_model/yolov4-tiny.cfg"

net = cv2.dnn.readNet(weightsPath, configPath)
model = cv2.dnn_DetectionModel(net)
model.setInputParams(size = (640, 640), scale = 1/255)

#Load class list
classes = []
with open("dnn_model/classes.txt","r") as fptr:
    for className in fptr.readlines():
        className = className.strip()
        classes.append(className)
#print(classes)

#Read the image
cap = cv2.imread(r'D:\Car Detection POC\CarDetectionVenv\img\image5.jpg')
cap = cv2.resize(cap, (640,640))

'''ATTEMPT 1'''
# while True:
#     (class_ids, scores, bboxes) = model.detect(cap) #, confThreshold = 0.9
#     for class_id, score, bbox in zip(class_ids, scores, bboxes):
#         (x, y, w, h) = bbox
#         className = classes[class_id]
#
#         if className == 'car':
#             cv2.putText(cap, className, (x, y-10), cv2.FONT_HERSHEY_PLAIN, 2, (200,0,50), 2)
#             # cv2.rectangle(cap, (x, y), (x+w, y+h), (33, 191, 130),3)
#             cv2.rectangle(cap, bbox, (33, 191, 130), 3)
#             # print(score,bbox)
#
#     cv2.imshow('ayush', cap)
#     if cv2.waitKey(33) == 27:
#         break

'''ATTEMPT 2'''
# (classIds, scores, bboxes) = model.detect(cap)
# # confThreshold = 0.9 this is returning only those who have confidence above 0.9 confThreshold isn't helping.
#
# # print(bboxes)
# # print(type(bboxes))
# # print(scores)
# # print(type(scores))
#
# for classId, score, bbox in zip(classIds, scores, bboxes):
#     (x, y, w, h) = bbox
#     className = classes[classId]
#
#     if className == 'car':
#         cv2.putText(cap, className, (x, y-10), cv2.FONT_HERSHEY_PLAIN, 2, (200,0,50), 2)
#         # cv2.rectangle(cap, (x, y), (x+w, y+h), (33, 191, 130),3)
#         cv2.rectangle(cap, bbox, (33, 191, 130), 3)
#         # print(score,bbox)
#
# cv2.imshow('ayush', cap)
# cv2.waitKey(0)

'''ATTEMPT 3'''
(classIds, scores, bboxes) = model.detect(cap)

bboxes = list(bboxes)
# print(np.array(scores).reshape(1,-1))
#print(scores)
#print(list(scores))
scores = list(scores) #list(np.array(scores).reshape(1,-1)[0])
# scores = list(map(float, scores))
# print(scores)
# print(scores)
# print(type(scores[0]))

indices = cv2.dnn.NMSBoxes(bboxes, scores, thresholdValue, nmsThresholdValue)
print(indices)
print(classIds)

for i in indices:
    # print(bboxes)
    bbox = bboxes[i]
    #print(bbox)
    #print(classIds[i])
    x, y, w, h = bbox[0], bbox[1], bbox[2], bbox[3]
    if classes[classIds[i]] == 'car':
        cv2.rectangle(cap, (x,y), (x+w, y+h), color = (0, 255, 0), thickness =2)
        cv2.putText(cap, classes[classIds[i]], (bbox[0], bbox[1] - 5), cv2.FONT_HERSHEY_PLAIN, 1.5, (200, 0, 50), 2)
        # cv2.putText(cap, str(scores[i]), (bbox[0]+10, bbox[1] - 7), cv2.FONT_HERSHEY_PLAIN, 1, (200, 0, 50), 2)
    # else:
    #     cv2.rectangle(cap, (x, y), (x + w, y + h), color=(0, 255, 0), thickness=2)
    #     cv2.putText(cap, classes[classIds[i]], (bbox[0], bbox[1] - 5), cv2.FONT_HERSHEY_PLAIN, 2, (200, 0, 50), 2)

cv2.imshow('ayush',cap)
cv2.waitKey(0)